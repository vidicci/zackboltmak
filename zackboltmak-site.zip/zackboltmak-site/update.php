<?php
include 'partials/header.php';
require __DIR__ . '/orders/orders.php';

if (!isset($_GET['orderid'])) {
    include "partials/not_found.php";
    exit;
}
$orderId = $_GET['orderid'];

$order = getOrderById($orderId);
if (!$order) {
    include "partials/not_found.php";
    exit;
}

$errors = [
    'orderstatus' => "",
];
    $order = updateOrder($_POST, $orderId);
    $order['orderstatus'] = "Completed";
    header("Location: index.php");