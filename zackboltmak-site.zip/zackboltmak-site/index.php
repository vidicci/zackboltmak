<?php
session_start();
if(!isset($_SESSION['alogin'])) {
    header('location: login.php');
}
else {
    require 'orders/orders.php';

    $orders = getOrders();

    include 'partials/header.php';
?>
<section class="tabledata d-flex justify-content-center align-items-center">
    <div class="container d-flex justify-content-center p-5">
        <div class="row">
            <a href="logout.php" class="btn btn-danger mb-2">Logout</a>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?php echo $order['orderid'] ?></td>
                        <td><?php echo $order['customer'] ?></td>
                        <td><?php if($order['invaddr'] == "") { echo "Address not provided"; } else { echo $order['invaddr']; } ?>
                        </td>
                        <!-- <td><?php if($order['orderstatus'] == 'Completed') { ?> <p class="text-white p-1 bg-success">
                                <?php echo $order['orderstatus'] ?></p> <?php } else { ?> <p
                                class="text-white p-1 bg-danger">
                                <?php echo $order['orderstatus'] ?></p> <?php } ?></td> -->
                        <td>
                            <a href="view.php?orderid=<?php echo $order['orderid'] ?>"
                                class="btn btn-sm btn-outline-info">View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>Order ID</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

</section>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap4.min.js"></script>
<script>
$(document).ready(function() {
    $('#example').DataTable();
});
</script>
</body>

</html>
<?php
}