<?php
include 'partials/header.php';
require __DIR__ . '/orders/orders.php';
if (isset($_GET['orderid'])) {
    ?>

<?php
}
$orderId = $_GET['orderid'];

$order = getOrderById($orderId);
if (!$order) {
    include "partials/not_found.php";
    exit;
}
?>
<div class="container mt-3">
    <div class="card">
        <div class="card-header">
            <h3>View Order: <b><?php echo $order['orderid']?></b></h3>
        </div>
        <!-- <div class="card-body">
            <a class="btn btn-success" href="update.php?orderid=<?php echo $order['orderid'] ?>">Mark Complete</a>
        </div> -->
        <table class="table">
            <tbody>
                <tr>
                    <th>Name:</th>
                    <td><?php echo $order['customer'] ?></td>
                </tr>
                <tr>
                    <th>Address:</th>
                    <td><?php if($order['invaddr'] == "") { echo '<p class="font-weight-bold text-danger">Address not provided</p>'; } else { echo $order['invaddr']; } ?>
                    </td>
                </tr>
                <tr>
                    <th>Total Price:</th>
                    <td>
                        <p class="font-weight-bold text-success"><?php echo '$', $order['totalprice'] ?></p>
                    </td>
                </tr>
                <tr>
                    <th>Comment:</th>
                    <td><?php if($order['comment'] == "") { echo '<p class="font-weight-bold text-danger">No Comments</p>'; } else { echo $order['comment']; } ?>
                    </td>
                </tr>
                <!-- <tr>
                    <th>Order Status:</th>
                    <td><?php if($order['orderstatus'] == 'Completed') { ?> <p class="text-white p-2 bg-success">
                            <?php echo $order['orderstatus'] ?></p> <?php } else { ?> <p
                            class="text-white p-2 bg-danger">
                            <?php echo $order['orderstatus'] ?></p> <?php } ?></td>
                </tr> -->
            </tbody>
        </table>

    </div>
    <div class="card mt-2 mb-2">
        <div class="card-header">
            <h1>Products</h1>
        </div>
        <div class="card-body">
            <table class="table">
                <tr>
                    <th>Product_No</th>
                    <th>Product Name</th>
                    <th>Code</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                </tr>
                <tbody>

                    <?php
                    $products = $order['products'];
                    $count = count($products);
                    $j = 1;
                    $i = 0;
                    for ($i = 0; $i < $count; $i++) {  
                    ?>
                    <tr>
                        <td><?php echo $j; ?></td>
                        <td><?php echo $order['products'][$i]['product']?></td>
                        <td><?php echo $order['products'][$i]['code']?></td>
                        <td><?php echo $order['products'][$i]['qty']?></td>
                        <td><?php echo "$", $order['products'][$i]['unit_price']?></td>
                    </tr>
                    <?php
                    $j++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
 include 'partials/footer.php' ?>