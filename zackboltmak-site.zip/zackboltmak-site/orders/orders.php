<?php
function getOrders()
{
    return json_decode(file_get_contents('http://www.cc.puv.fi/~asa/json/project.json'), true);
}

function getOrderById($orderid)
{
    $orders = getOrders();
    foreach ($orders as $order) {
        if ($order['orderid'] == $orderid) {
            return $order;
        }
    }
    return null;
}

function updateOrder($data, $orderid)
{
    $updateOrder = [];
    $orders = getOrders();
    foreach ($orders as $i => $order) {
        if ($order['orderid'] == $orderid) {
            $orders[$i] = $updateOrder = array_merge($order, $data);
        }
    }

    putJson($orders);

    return $updateOrder;
}

function putJson($orders)
{
    file_put_contents('http://www.cc.puv.fi/~asa/json/project.json', json_encode($orders, JSON_PRETTY_PRINT));
}